"use client";

import AppShell from "@/components/AppShell";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";

type Announcement = { id: string; title: string; body: string; createdAt: string; pinned?: boolean };

async function fetchAnnouncements(): Promise<Announcement[]> {
  const r = await fetch("/api/v1/announcements", { cache: "no-store", credentials: "include" });
  if (r.status === 401) {
    window.location.href = `/api/auth/start?return_to=${encodeURIComponent("/announcements")}`;
    return [];
  }
  if (!r.ok) throw new Error("announcements_load_failed");
  const json = await r.json().catch(() => ({}));
  return Array.isArray(json) ? json : Array.isArray(json?.data) ? json.data : [];
}

export default function AnnouncementsPage() {
  const { data = [], isLoading, error } = useQuery({
    queryKey: ["announcements"],
    queryFn: fetchAnnouncements,
    retry: false,
    refetchOnWindowFocus: false,
  });

  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return data;
    return data.filter((a) =>
      [a.title, a.body].filter(Boolean).join(" ").toLowerCase().includes(s)
    );
  }, [data, q]);

  return (
    <AppShell>
      <main className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Announcements</h1>
        </div>

        <div className="flex items-center justify-between">
          <input
            className="w-64 border rounded px-3 py-2"
            placeholder="Search title / body…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>

        {isLoading && <p>Loading…</p>}
        {error && <p className="text-red-600">Failed to load announcements.</p>}

        {!isLoading && !error && (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((a) => (
              <div key={a.id} className="border rounded p-4">
                <div className="flex items-start justify-between gap-4">
                  <h2 className="font-semibold">{a.title}</h2>
                  <span className="text-xs text-gray-500">{new Date(a.createdAt).toLocaleString()}</span>
                </div>
                <p className="mt-2 text-sm whitespace-pre-wrap">{a.body}</p>
                {a.pinned && (
                  <span className="mt-2 inline-block text-xs text-yellow-600 font-semibold">
                    📌 Pinned
                  </span>
                )}
              </div>
            ))}
            {filtered.length === 0 && <p className="text-muted-foreground">No announcements.</p>}
          </div>
        )}
      </main>
    </AppShell>
  );
}