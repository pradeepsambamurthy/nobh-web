"use client";

import AppShell from "@/components/AppShell";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";

type Resident = { id: string; name: string; unit: string; phone: string };

async function fetchResidents(): Promise<Resident[]> {
  const r = await fetch("/api/v1/residents", { cache: "no-store", credentials: "include" });
  if (r.status === 401) {
    window.location.href = `/api/auth/start?return_to=${encodeURIComponent("/residents")}`;
    return [];
  }
  if (!r.ok) throw new Error("residents_load_failed");
  const json = await r.json().catch(() => ({}));
  return Array.isArray(json) ? json : Array.isArray(json?.data) ? json.data : [];
}

export default function ResidentsPage() {
  const { data = [], isLoading, error } = useQuery({
    queryKey: ["residents"],
    queryFn: fetchResidents,
    retry: false,
    refetchOnWindowFocus: false,
  });

  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return data;
    return data.filter((r) =>
      [r.name, r.unit, r.phone].filter(Boolean).join(" ").toLowerCase().includes(s)
    );
  }, [data, q]);

  return (
    <AppShell>
      <main className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Residents</h1>
          <input
            className="w-64 border rounded px-3 py-2"
            placeholder="Search name / unit / phone…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>

        {isLoading && <p>Loading…</p>}
        {error && <p className="text-red-600">Failed to load residents.</p>}

        {!isLoading && !error && (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((r) => (
              <div key={r.id} className="border rounded p-4">
                <div className="font-semibold">{r.name}</div>
                <div className="text-sm text-muted-foreground">{r.unit}</div>
                <div className="text-sm">{r.phone}</div>
              </div>
            ))}
            {filtered.length === 0 && <p className="text-muted-foreground">No residents found.</p>}
          </div>
        )}
      </main>
    </AppShell>
  );
}